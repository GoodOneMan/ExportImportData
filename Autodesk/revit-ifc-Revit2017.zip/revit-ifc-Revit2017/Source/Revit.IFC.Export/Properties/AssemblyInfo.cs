using System.Reflection;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("IFC Exporter for Revit")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Autodesk, Inc.")]
[assembly: AssemblyProduct("IFC Exporter for Revit")]
[assembly: AssemblyCopyright("� 2012-2017 Autodesk, Inc. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: AssemblyVersion("19.1.0.0")]
[assembly: AssemblyFileVersion("19.1.0.0")]

#region Using directives

#endregion
